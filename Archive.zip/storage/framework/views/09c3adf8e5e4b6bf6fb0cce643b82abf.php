<?php use App\Services\StudentResultService; ?>
    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?> </title>
    <script src="<?php echo e(public_path('tailwind.js')); ?>"></script>
    <link href="<?php echo e(public_path('daisy.css')); ?>" rel="stylesheet" type="text/css"/>
</head>
<body>

    <div class="bg-gray-200 p-4 flex justify-center">
        <div class="relative w-full bg-white p-4 overflow-hidden">

            <div class="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-[0.1]">
                <div class="px-10 py-5 flex w-full h-full flex-col justify-center items-center">
                    <img class="w-96" src="<?php echo e(public_path('images/logo.jpg')); ?>" alt="">
                </div>
            </div>

            <div class="absolute inset-0 opacity-[0.02] pointer-events-none flex flex-wrap gap-20 p-10">
                <?php for($i = 0; $i < 20; $i++): ?>
                    <span class="text-xs font-bold uppercase rotate-12">Ozoveheni</span>
                <?php endfor; ?>
            </div>

            <div class="relative z-10">
                <div class="flex justify-between items-center border-b-4 border-double border-primary pb-6 mb-4">
                    <img src="<?php echo e(public_path('images/logo.jpg')); ?>" alt="School Logo" class="w-24 h-24 grayscale">

                    <div class="text-center flex-1 gap-1">
                        <h1 class="text-2xl font-black uppercase text-gray-800">Ozoveheni College Of Health Technology</h1>
                        <p class="text-xs font-serif uppercase tracking-widest text-gray-500">Office of the Registrar (Academic Division)</p>
                        <div class="mt-4 badge badge-primary badge-outline font-bold px-6 capitalize"><?php echo e($exam->title); ?> (<?php echo e($exam->subtitle); ?>) <sapn class="uppercase px-1"><?php echo e($student->level); ?></sapn>  RESULT</div>
                    </div>

                    <div class="avatar">
                        <div class="w-24 h-28 rounded-sm ring-1 ring-gray-400">
                            <img src="<?php echo e(public_path("storage/$student->photo")); ?>" alt="Student Passport"/>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4 bg-gray-50 p-4 rounded-lg border border-gray-100">
                    <div class="space-y-1">
                        <p class="text-[10px] text-gray-500 uppercase font-bold">Student Name</p>
                        <p class="font-bold text-lg"><?php echo e($student->last_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->first_name); ?></p>
                    </div>
                    <div class="text-right space-y-1">
                        <p class="text-[10px] text-gray-500 uppercase font-bold">Matriculation Number</p>
                        <p class="font-mono font-bold text-lg"><?php echo e($student->reg_no); ?></p>
                    </div>
                </div>

                <table class="table w-full border border-gray-300">
                    <thead class="bg-gray-100 text-gray-700">
                    <tr class="text-center border-b border-gray-300">
                        <th class="border-r border-gray-300 w-24">CODE</th>
                        <th class="text-left border-r border-gray-300">COURSE TITLE</th>
                        <th>1st CA</th>
                        <th>2nd CA</th>
                        <th>EXAM</th>
                        <th>TOTAL</th>
                        <th>REMARK</th>
                    </tr>
                    </thead>
                    <tbody class="text-xs font-semibold">
                    <?php $__currentLoopData = $singleExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleExam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center border-b border-gray-200">
                            <td class="bg-gray-50"><?php echo e($singleExam->course->code); ?></td>
                            <td class="text-left"><?php echo e($singleExam->course->name); ?></td>
                            <td><?php echo e(StudentResultService::courseScore($student, $singleExam->course, $exam, 'first_ca')); ?></td>
                            <td><?php echo e(StudentResultService::courseScore($student, $singleExam->course, $exam, 'second_ca')); ?></td>
                            <td><?php echo e(StudentResultService::courseScore($student, $singleExam->course, $exam, 'exam')); ?></td>
                            <td class="font-bold"><?php echo e(StudentResultService::courseTotalScore($student, $singleExam->course, $exam)); ?></td>
                            <td><span><?php echo e(StudentResultService::courseGrade($student, $singleExam->course, $exam)); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <div class="mt-8 flex w-full">
                    <div class="w-full border border-base-300 card">
                        <div class="p-3 flex justify-between items-center">
                            <h1 class="font-bold text-md">CGPA</h1>
                            <h1 class="font-black text-md"><?php echo e(number_format(StudentResultService::calculateCGPA($student, $exam), 2)); ?></h1>
                        </div>
                    </div>

                    <div class="w-full border border-base-300 card">
                        <div class="p-3 flex justify-between items-center">
                            <h1 class="font-bold text-md">Remark</h1>
                            <h1 class="font-black text-md"><?php echo e(StudentResultService::remarks($student, $exam)); ?></h1>
                        </div>
                    </div>
                </div>













            </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH /Users/zubdev/Devs/desktop/ozov/cbt-exam-backend/resources/views/student-result-slip.blade.php ENDPATH**/ ?>