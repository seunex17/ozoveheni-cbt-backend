<?php use App\Services\ReportService;use App\Services\StudentResultService; ?>
    <!doctype html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <title>Departmental Broadsheet</title>
    <script src="<?php echo e(public_path('tailwind.js')); ?>"></script>
    <link href="<?php echo e(public_path('daisy.css')); ?>" rel="stylesheet" type="text/css"/>
    <style>
        @page {
            margin: 20px;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: white;
            color: black;
        }

        /* Strict borders for printing */
        table {
            border-collapse: collapse;
            width: 100%;
            page-break-inside: auto;
        }

        thead {
            /* This is the magic line that repeats the header */
            display: table-header-group;
        }

        tr {
            /* Prevents a single row from being split across two pages */
            page-break-inside: avoid;
            page-break-after: auto;
        }

        /* Optional: Add a little padding at the top of new pages */
        thead tr th {
            position: sticky;
            top: 0;
        }

        th, td {
            border: 1px solid #000 !important;
            padding: 4px 2px !important;
            text-align: center;
            font-size: 9px;
        }

        .course-header {
            font-size: 8px;
            font-weight: bold;
            background: #f3f4f6;
        }

        .vertical-text {
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            padding: 5px 2px;
        }
    </style>
</head>
<body class="p-2">

    <div class="flex items-center justify-between mb-4 border-b-2 border-black pb-2">
        <div class="flex items-center gap-3">
            <img src="data:image/png;base64,<?php echo e(base64_encode(file_get_contents(public_path('images/logo.jpg')))); ?>" class="h-12">
            <div>
                <h1 class="text-lg font-bold uppercase">Ozoveheni College of Health Technology</h1>
                <p class="text-xs italic">Department of <?php echo e($exam->department->name); ?> — <?php echo e($exam->title); ?> Broadsheet (<?php echo e($exam->subtitle); ?>)</p>
            </div>
        </div>
        <div class="text-right text-[10px]">
            <p><strong>GPA:</strong> Grade Point Average</p>
        </div>
    </div>

    <table class="mt-3">
        <thead>
        <tr class="bg-gray-100">
            <th class="w-8">S/N</th>
            <th class="w-48 text-left px-2">Reg No</th>
            <?php $__currentLoopData = $singleExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleExam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th class="w-16"><?php echo e($singleExam->course->code); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <th class="w-16">RMK</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td class="text-left px-2 font-semibold">
                    <div class="text-[14px]"><?php echo e($student->reg_no); ?></div>
                </td>

                <?php $__currentLoopData = $singleExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="font-bold text-[14px]">
                        <?php echo e(ReportService::score($exam, $student, $result->course)); ?>

                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td class="font-black text-[14px]"><?php echo e(StudentResultService::courseGrade($student, $singleExam->course, $exam)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="mt-12 flex justify-between px-10">
        <div class="text-center">
            <div class="border-t border-black w-40 mb-1"></div>
            <p class="text-[9px] font-bold">EXAM OFFICER</p>
        </div>
        <div class="text-center">
            <div class="border-t border-black w-40 mb-1"></div>
            <p class="text-[9px] font-bold">H.O.D. ACCOUNTANCY</p>
        </div>
        <div class="text-center">
            <div class="border-t border-black w-40 mb-1"></div>
            <p class="text-[9px] font-bold">COLLEGE REGISTRAR</p>
        </div>
    </div>

</body>
</html>
<?php /**PATH /Users/zubdev/Devs/desktop/ozov/cbt-exam-backend/resources/views/report.blade.php ENDPATH**/ ?>