<?php

return [
    'fruitcake/laravel-debugbar' => [
        'aliases' => [
            'Debugbar' => 'Fruitcake\\LaravelDebugbar\\Facades\\Debugbar',
        ],
        'providers' => [
            0 => 'Fruitcake\\LaravelDebugbar\\ServiceProvider',
        ],
    ],
    'inertiajs/inertia-laravel' => [
        'providers' => [
            0 => 'Inertia\\ServiceProvider',
        ],
    ],
    'laravel/boost' => [
        'providers' => [
            0 => 'Laravel\\Boost\\BoostServiceProvider',
        ],
    ],
    'laravel/mcp' => [
        'aliases' => [
            'Mcp' => 'Laravel\\Mcp\\Server\\Facades\\Mcp',
        ],
        'providers' => [
            0 => 'Laravel\\Mcp\\Server\\McpServiceProvider',
        ],
    ],
    'laravel/octane' => [
        'aliases' => [
            'Octane' => 'Laravel\\Octane\\Facades\\Octane',
        ],
        'providers' => [
            0 => 'Laravel\\Octane\\OctaneServiceProvider',
        ],
    ],
    'laravel/pail' => [
        'providers' => [
            0 => 'Laravel\\Pail\\PailServiceProvider',
        ],
    ],
    'laravel/reverb' => [
        'providers' => [
            0 => 'Laravel\\Reverb\\ApplicationManagerServiceProvider',
            1 => 'Laravel\\Reverb\\ReverbServiceProvider',
        ],
    ],
    'laravel/roster' => [
        'providers' => [
            0 => 'Laravel\\Roster\\RosterServiceProvider',
        ],
    ],
    'laravel/sail' => [
        'providers' => [
            0 => 'Laravel\\Sail\\SailServiceProvider',
        ],
    ],
    'laravel/sanctum' => [
        'providers' => [
            0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
        ],
    ],
    'laravel/tinker' => [
        'providers' => [
            0 => 'Laravel\\Tinker\\TinkerServiceProvider',
        ],
    ],
    'nesbot/carbon' => [
        'providers' => [
            0 => 'Carbon\\Laravel\\ServiceProvider',
        ],
    ],
    'nunomaduro/collision' => [
        'providers' => [
            0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
        ],
    ],
    'nunomaduro/termwind' => [
        'providers' => [
            0 => 'Termwind\\Laravel\\TermwindServiceProvider',
        ],
    ],
    'pestphp/pest-plugin-laravel' => [
        'providers' => [
            0 => 'Pest\\Laravel\\PestServiceProvider',
        ],
    ],
];
